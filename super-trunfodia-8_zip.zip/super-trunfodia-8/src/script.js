var all_cards = [
  (card1 = {
    name: "druida",
    img:
      "https://i0.wp.com/orbedosdragoes.com/wp-content/uploads/2016/12/DD5_Druida.jpg?resize=480%2C360&ssl=1",
    att: {
      attack: 6,
      defense: 8,
      mage: 8
    }
  }),
  (card2 = {
    name: "ladino",
    img:
      "http://pm1.narvii.com/6388/552a67c7a1118c20bc457a81bedae4b64b061412_00.jpg",
    att: {
      attack: 9,
      defense: 6,
      mage: 4
    }
  }),
  (card3 = {
    name: "caçador",
    img:
      "https://i.pinimg.com/550x/92/5a/97/925a97eef1dad8b82f3d66f4da98c0b7.jpg",
    att: {
      attack: 8,
      defense: 5,
      mage: 6
    }
  }),
  (card4 = {
    name: "bruxo",
    img:
      "https://1.bp.blogspot.com/-NmVxGCcQcmk/XZSBGxs2sYI/AAAAAAAAA7o/u9QcKFflof80nX5twFPbC7rrQ1lBY441ACLcBGAsYHQ/s640/bruxito.jpg",
    att: {
      attack: 2,
      defense: 4,
      mage: 9
    }
  }),
  (card5 = {
    name: "paladino",
    img:
      "https://1.bp.blogspot.com/-GnhY9uiY-38/V_-QwtEdjhI/AAAAAAAAFHA/tcOe4HHlAjUOOO-SLNleonjphiGVNgi2QCEw/s1600/maxresdefault.jpg",
    att: {
      attack: 7,
      defense: 8,
      mage: 5
    }
  }),
  (card6 = {
    name: "mage",
    img:
      "https://preview.redd.it/wuhz047c54c81.jpg?width=640&crop=smart&auto=webp&s=049ce7646734cbfea6e8fffcf9893905a6f4388e",
    att: {
      attack: 2,
      defense: 7,
      mage: 9
    }
  }),
  (card7 = {
    name: "guerreiro",
    img:
      "https://wallup.net/wp-content/uploads/2018/10/03/963519-diablo-dark-fantasy-warrior-rpg-action-fighting-dungeon.jpg",
    att: {
      attack: 8,
      defense: 8,
      mage: 0
    }
  }),
  (card8 = {
    name: "sacerdote",
    img: "https://cdn.ligadosgames.com/imagens/sacerdote-cke.jpg",
    att: {
      attack: 6,
      defense: 5,
      mage: 7
    }
  })
];
var card_coop;
var card_player;

function sortearCarta() {
  card_coop = all_cards[parseInt(Math.random() * 8)];

  card_player = all_cards[parseInt(Math.random() * 8)];

  while (card_player == card_coop) {
    card_player = all_cards[parseInt(Math.random() * 8)];
  }
  console.log(card_player);
  document.getElementById("btnSortear").disabled = true;
  document.getElementById("btnJogar").disabled = false;

  display_card_player();
}

function attributes_select() {
  var radio_attributes = document.getElementsByName("attributes");

  for (var i = 0; i < radio_attributes.length; i++) {
    if (radio_attributes[i].checked == true) {
      return radio_attributes[i].value;
    }
  }
}

function jogar() {
  var att_sel = attributes_select();
  var div_result = document.getElementById("resultado");

  if (card_player.att[att_sel] > card_coop.att[att_sel]) {
    HTML_result = "<p class='resultado-final'>Venceu</p>";
  } else if (card_coop.att[att_sel] > card_player.att[att_sel]) {
    HTML_result = "<p class='resultado-final'>perdeu</p>";
  } else {
    HTML_result = "<p class='resultado-final'>empatou</p>";
  }
  div_result.innerHTML = HTML_result;
  document.getElementById("btnJogar").disableb = true;
  display_card_coop();
}

function display_card_player() {
  div_card_player = document.getElementById("carta-jogador");
  div_card_player.style.backgroundImage = `url(${card_player.img})`;
  var frame_card =
    '<img src="https://legaldbol.com/wp-content/uploads/2019/03/48-Free-Printable-Card-Template-Hearthstone-in-Photoshop-by-Card-Template-Hearthstone.jpg" style=" width: inherit; height: inherit; position: absolute;">';
  var tagHTML = "<div id= 'opcoes' class='carta-status'>";

  var option_text = "";
  for (var attributes in card_player.att) {
    option_text +=
      "<input type='radio' name='attributes' value='" +
      attributes +
      "'>" +
      attributes +
      ": " +
      card_player.att[attributes] +
      "<br>";

    var name = `<p class="carta-subtitle">${card_player.name}</p>`;

    div_card_player.innerHTML =
      frame_card + name + tagHTML + option_text + "</div>";
  }
}

function display_card_coop() {
  div_card_coop = document.getElementById("carta-maquina");
  div_card_coop.style.backgroundImage = `url(${card_coop.img})`;
  var frame_card =
    '<img src="https://legaldbol.com/wp-content/uploads/2019/03/48-Free-Printable-Card-Template-Hearthstone-in-Photoshop-by-Card-Template-Hearthstone.jpg" style=" width: inherit; height: inherit; position: absolute;">';
  var tagHTML = "<div id= 'opcoes' class='carta-status'>";

  var option_text = "";
  for (var attributes in card_coop.att) {
    option_text +=
      "<p type='text' name='attributes' value='" +
      attributes +
      "'>" +
      attributes +
      ": " +
      card_coop.att[attributes] +
      "</p>";

    var name = `<p class="carta-subtitle">${card_coop.name}</p>`;

    div_card_coop.innerHTML =
      frame_card + name + tagHTML + option_text + "</div>";
  }
}
