# Super Trunfo - Dia 8

A Pen created on CodePen.io. Original URL: [https://codepen.io/iam-raminhos/pen/eYypQpR](https://codepen.io/iam-raminhos/pen/eYypQpR).

